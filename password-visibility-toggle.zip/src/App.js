import "./App.scss";
import Login from "./components/login/Login";

function App() {
  return (
    <div>
      <Login />
    </div>
  );
}

export default App;
